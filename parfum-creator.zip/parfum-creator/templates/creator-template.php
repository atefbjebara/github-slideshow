<div class="parfum-creator-container">

<html lang="fr">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créez Votre Parfum Unique</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    


    <div class="parfum-creator">
        <h1>Créez Votre Parfum Unique</h1>

        <div class="concentration-section">
            <h2 class="concentration-title">Sélectionnez la concentration de parfum:</h2>
            <div class="concentration-options">
                <div class="concentration-option" data-concentration="cologne">
                    <div class="concentration-name">Eau de Cologne (EDC)</div>
                    <div class="concentration-percentage">(2-5%)</div>
                    <div class="concentration-details">Tenue : 2-3 heures<br>Idéal pour : Journées chaudes, légèreté</div>
                </div>
                <div class="concentration-option" data-concentration="toilette">
                    <div class="concentration-name">Eau de Toilette (EDT)</div>
                    <div class="concentration-percentage">(5-15%)</div>
                    <div class="concentration-details">Tenue : 3-6 heures<br>Idéal pour : Usage quotidien, décontracté</div>
                </div>
                <div class="concentration-option" data-concentration="parfum-eau">
                    <div class="concentration-name">Eau de Parfum (EDP)</div>
                    <div class="concentration-percentage">(15-20%)</div>
                    <div class="concentration-details">Tenue : 6-8 heures<br>Idéal pour : Soirées, événements spéciaux</div>
                </div>
                <div class="concentration-option" data-concentration="parfum">
                    <div class="concentration-name">Parfum (Extrait)</div>
                    <div class="concentration-percentage">(20-30%)</div>
                    <div class="concentration-details">Tenue : 8-12 heures<br>Idéal pour : Occasions spéciales, luxe</div>
                </div>
            </div>
        </div>

        <div class="creation-steps">
            <div class="note-category">
                <h2>Notes de Tête</h2>
                <select class="note-selector" id="head-notes">
                    <optgroup label="Agrumes">
                        <option value="Bergamote">Bergamote - Fraîche et légèrement épicée</option>
                        <option value="Orange">Orange - Douce et ensoleillée</option>
                        <option value="Citron">Citron - Acidulé et rafraîchissant</option>
                        <option value="Pamplemousse">Pamplemousse - Amer et pétillant</option>
                    </optgroup>
                    <optgroup label="Fruits">
                        <option value="Pomme">Pomme - Croquante et sucrée</option>
                        <option value="Poire">Poire - Juteuse et florale</option>
                        <option value="Baies Rouges">Baies Rouges - Acidulées et gourmandes</option>
                    </optgroup>
                    <optgroup label="Herbes aromatiques">
                        <option value="Lavande">Lavande - Fraîche et apaisante</option>
                        <option value="Romarin">Romarin - Herbacé et camphré</option>
                        <option value="Basilic">Basilic - Vert et poivré</option>
                    </optgroup>
                    <optgroup label="Notes aquatiques">
                        <option value="Calone">Calone - Air marin et fraîcheur</option>
                        <option value="Melon d'eau">Melon d'eau - Juteux et rafraîchissant</option>
                    </optgroup>
                    <optgroup label="Épices légères">
                        <option value="Gingembre">Gingembre - Piquant et citronné</option>
                        <option value="Poivre Rose">Poivre Rose - Doux et fruité</option>
                    </optgroup>
                    <optgroup label="Fleurs fraîches">
                        <option value="Néroli">Néroli - Florale et légèrement amère</option>
                        <option value="Pétales de Rose">Pétales de Rose - Fraîches et délicates</option>
                    </optgroup>
                    <optgroup label="Notes vertes">
                        <option value="Feuilles de Violette">Feuilles de Violette - Vertes et terreuses</option>
                        <option value="Galbanum">Galbanum - Vert et résineux</option>
                    </optgroup>
                    <optgroup label="Notes aromatiques">
                        <option value="Eucalyptus">Eucalyptus - Frais et camphré</option>
                        <option value="Menthe">Menthe - Rafraîchissante et vivifiante</option>
                    </optgroup>
                </select>
                <button class="add-note-btn" onclick="addNote('head')">Ajouter</button>
            </div>

            <div class="note-category">
                <h2>Notes de Cœur</h2>
                <select class="note-selector" id="heart-notes">
                    <optgroup label="Fleurs classiques">
                        <option value="Rose">Rose - Intemporelle, douce et épicée</option>
                        <option value="Jasmin">Jasmin - Sensuel et floral</option>
                        <option value="Fleur d'Oranger">Fleur d'Oranger - Douce et légèrement amère</option>
                        <option value="Tubéreuse">Tubéreuse - Opulente et crémeuse</option>
                    </optgroup>
                    <optgroup label="Fruits">
                        <option value="Pêche">Pêche - Douce et juteuse</option>
                        <option value="Framboise">Framboise - Acidulée et gourmande</option>
                        <option value="Figue">Figue - Douce et lactée</option>
                    </optgroup>
                    <optgroup label="Épices">
                        <option value="Cannelle">Cannelle - Chaude et sucrée</option>
                        <option value="Cardamome">Cardamome - Épicée et citronnée</option>
                        <option value="Clou de Girofle">Clou de Girofle - Puissant et médicinal</option>
                    </optgroup>
                    <optgroup label="Notes boisées">
                        <option value="Santal">Santal - Doux et crémeux</option>
                        <option value="Cèdre">Cèdre - Sec et résineux</option>
                        <option value="Patchouli">Patchouli - Terreux et boisé</option>
                    </optgroup>
                </select>
                <button class="add-note-btn" onclick="addNote('heart')">Ajouter</button>
            </div>

            <div class="note-category">
                <h2>Notes de Fond</h2>
                <select class="note-selector" id="base-notes">
                    <optgroup label="Bois">
                        <option value="Santal">Santal - Doux, crémeux et boisé</option>
                        <option value="Cèdre">Cèdre - Sec, boisé et résineux</option>
                        <option value="Vétiver">Vétiver - Terreux, boisé et fumé</option>
                        <option value="Patchouli">Patchouli - Terreux, boisé et sucré</option>
                    </optgroup>
                    <optgroup label="Orientales/Gourmandes">
                        <option value="Vanille">Vanille - Douce, gourmande et réconfortante</option>
                        <option value="Ambre">Ambre - Chaude, résineuse et sucrée</option>
                        <option value="Tonka">Tonka - Douce, vanillée et amandée</option>
                    </optgroup>
                    <optgroup label="Muscs">
                        <option value="Musc Blanc">Musc Blanc - Doux, propre et poudré</option>
                        <option value="Musc Animal">Musc Animal - Sensuel et profond</option>
                    </optgroup>
                    <optgroup label="Cuirs">
                        <option value="Cuir">Cuir - Sec, fumé et animal</option>
                        <option value="Suède">Suède - Doux et velouté</option>
                    </optgroup>
                    <optgroup label="Résines">
                        <option value="Encens">Encens - Mystique et fumé</option>
                        <option value="Myrrhe">Myrrhe - Amère et résineuse</option>
                        <option value="Benjoin">Benjoin - Doux et balsamique</option>
                    </optgroup>
                    <optgroup label="Mousses">
                        <option value="Mousse de Chêne">Mousse de Chêne - Verte et terreuse</option>
                    </optgroup>
                </select>
                <button class="add-note-btn" onclick="addNote('base')">Ajouter</button>
            </div>
        </div>

        <div class="volume-selection">
            <h2 class="volume-title">Sélectionnez le volume total de la composition:</h2>
            <div class="volume-options">
                <div class="volume-option" data-volume="30">
                    <div class="volume-name">30 ml</div>
                    <div class="volume-price">(+15 DT)</div>
                </div>
                <div class="volume-option" data-volume="50">
                    <div class="volume-name">50 ml</div>
                    <div class="volume-price">(+20 DT)</div>
                </div>
                <div class="volume-option" data-volume="100">
                    <div class="volume-name">100 ml</div>
                    <div class="volume-price">(+35 DT)</div>
                </div>
            </div>
        </div>

        <div class="selected-notes">
            <h3>Votre Composition:</h3>
            <div id="selected-notes-list"></div>
            <div class="price-calculator">
                Prix total: <span id="total-price">0</span> DT
                <div id="price-details"></div>
            </div>
        </div>

        <button class="checkout-btn" onclick="finalizeOrder()">Finaliser Ma Création</button>
    </div>
    


</div>