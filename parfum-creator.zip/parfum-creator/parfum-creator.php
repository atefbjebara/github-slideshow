<?php
/**
 * Plugin Name: Parfum Creator
 * Description: Un plugin pour créer des parfums personnalisés
 * Version: 1.0
 * Author: Replit User
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue styles and scripts
function parfum_creator_enqueue_scripts() {
    wp_enqueue_style('parfum-creator-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_enqueue_script('parfum-creator-script', plugin_dir_url(__FILE__) . 'assets/js/parfum.js', array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'parfum_creator_enqueue_scripts');

// Shortcode to display the parfum creator
function parfum_creator_shortcode() {
    ob_start();
    include_once(plugin_dir_path(__FILE__) . 'templates/creator-template.php');
    return ob_get_clean();
}
add_shortcode('parfum_creator', 'parfum_creator_shortcode');
