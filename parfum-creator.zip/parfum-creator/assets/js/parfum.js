
document.addEventListener('DOMContentLoaded', function() {
    // Variables pour le suivi de la sélection
    let selectedConcentration = null;
    let selectedVolume = null;
    let selectedNotes = {
        head: [],
        heart: [],
        base: []
    };

    // Prix de base des concentrations
    const concentrationPrices = {
        'cologne': 25,
        'toilette': 35,
        'parfum-eau': 45,
        'parfum': 60
    };

    // Prix de base des volumes
    const volumePrices = {
        '30': 15,
        '50': 20,
        '100': 35
    };

    // Initialisation des écouteurs d'événements
    initEventListeners();

    function initEventListeners() {
        // Écouteurs pour les options de concentration
        const concentrationOptions = document.querySelectorAll('.concentration-option');
        concentrationOptions.forEach(option => {
            option.addEventListener('click', function() {
                selectConcentration(this.getAttribute('data-concentration'));
            });
        });

        // Écouteurs pour les options de volume
        const volumeOptions = document.querySelectorAll('.volume-option');
        volumeOptions.forEach(option => {
            option.addEventListener('click', function() {
                selectVolume(this.getAttribute('data-volume'));
            });
        });

        // Fonction pour ajouter une note
        window.addNote = function(type) {
            const selector = document.getElementById(`${type}-notes`);
            const selectedValue = selector.value;
            const selectedText = selector.selectedOptions[0].text;
            
            if (selectedValue && !selectedNotes[type].find(note => note.value === selectedValue)) {
                selectedNotes[type].push({
                    value: selectedValue,
                    text: selectedText
                });
                updateNotesList();
                updatePrice();
            }
        };

        // Fonction pour supprimer une note
        window.removeNote = function(type, value) {
            selectedNotes[type] = selectedNotes[type].filter(note => note.value !== value);
            updateNotesList();
            updatePrice();
        };

        // Fonction pour finaliser la commande
        window.finalizeOrder = function() {
            if (!selectedConcentration || !selectedVolume || 
                selectedNotes.head.length === 0 || 
                selectedNotes.heart.length === 0 || 
                selectedNotes.base.length === 0) {
                alert('Veuillez compléter votre sélection avant de finaliser votre commande.');
                return;
            }
            
            // Ici, vous pouvez ajouter la logique pour soumettre la commande
            alert('Votre parfum personnalisé a été ajouté au panier !');
        };
    }

    function selectConcentration(concentration) {
        selectedConcentration = concentration;
        
        // Mise à jour visuelle
        const options = document.querySelectorAll('.concentration-option');
        options.forEach(option => {
            if (option.getAttribute('data-concentration') === concentration) {
                option.classList.add('selected');
            } else {
                option.classList.remove('selected');
            }
        });
        
        updatePrice();
    }

    function selectVolume(volume) {
        selectedVolume = volume;
        
        // Mise à jour visuelle
        const options = document.querySelectorAll('.volume-option');
        options.forEach(option => {
            if (option.getAttribute('data-volume') === volume) {
                option.classList.add('selected');
            } else {
                option.classList.remove('selected');
            }
        });
        
        updatePrice();
    }

    function updateNotesList() {
        const container = document.getElementById('selected-notes-list');
        
        if (!container) return;
        
        let html = '';
        
        // Notes de tête
        if (selectedNotes.head.length > 0) {
            html += '<div class="notes-group"><h4>Notes de Tête:</h4>';
            selectedNotes.head.forEach(note => {
                html += `<div class="note-pill">${note.text} <span onclick="removeNote('head', '${note.value}')">&times;</span></div>`;
            });
            html += '</div>';
        }
        
        // Notes de coeur
        if (selectedNotes.heart.length > 0) {
            html += '<div class="notes-group"><h4>Notes de Cœur:</h4>';
            selectedNotes.heart.forEach(note => {
                html += `<div class="note-pill">${note.text} <span onclick="removeNote('heart', '${note.value}')">&times;</span></div>`;
            });
            html += '</div>';
        }
        
        // Notes de fond
        if (selectedNotes.base.length > 0) {
            html += '<div class="notes-group"><h4>Notes de Fond:</h4>';
            selectedNotes.base.forEach(note => {
                html += `<div class="note-pill">${note.text} <span onclick="removeNote('base', '${note.value}')">&times;</span></div>`;
            });
            html += '</div>';
        }
        
        container.innerHTML = html;
    }

    function updatePrice() {
        const priceElement = document.getElementById('total-price');
        const detailsElement = document.getElementById('price-details');
        
        if (!priceElement || !detailsElement) return;
        
        let totalPrice = 0;
        let details = '';
        
        // Prix de la concentration
        if (selectedConcentration) {
            const concentrationPrice = concentrationPrices[selectedConcentration];
            totalPrice += concentrationPrice;
            details += `<div>Concentration (${selectedConcentration}): ${concentrationPrice} DT</div>`;
        }
        
        // Prix du volume
        if (selectedVolume) {
            const volumePrice = volumePrices[selectedVolume];
            totalPrice += volumePrice;
            details += `<div>Volume (${selectedVolume} ml): ${volumePrice} DT</div>`;
        }
        
        // Prix des notes (supposons 5 DT par note)
        const totalNotes = selectedNotes.head.length + selectedNotes.heart.length + selectedNotes.base.length;
        if (totalNotes > 0) {
            const notesPrice = totalNotes * 5;
            totalPrice += notesPrice;
            details += `<div>${totalNotes} Notes: ${notesPrice} DT</div>`;
        }
        
        priceElement.textContent = totalPrice;
        detailsElement.innerHTML = details;
    }
});
